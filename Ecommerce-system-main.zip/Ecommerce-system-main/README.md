
# Ecommerce System

**A web-based second-hand product selling platform designed for M/N Technology at Makuza Peace Plaza.** This system focuses on improving the buying experience by providing an easy-to-use interface, secure payment methods, and real-time notifications, with **M/N Technology** as the main seller and admin.

---

## 📖 **Project Overview**

The **Ecommerce System** allows buyers to easily browse, search, and purchase second-hand products from **M/N Technology**. The platform streamlines the buying process and ensures a secure and user-friendly experience, addressing the need for a centralized platform for second-hand product sales.

---

## 🎯 **Features**

- **User-friendly Interface**: Easy browsing and searching for buyers.
- **Secure Payment Gateway**: Ensures safe and encrypted transactions.
- **Real-time Notifications**: Alerts buyers about product availability and order updates.
- **Product Management**: Admin functionality for managing products, orders, and inventory.

---

## 💡 **Technologies Used**

- **Frontend**: HTML, CSS, JavaScript (with Bootstrap for responsive design)
- **Backend**: PHP
- **Database**: MySQL
- **Server**: XAMPP (or WAMP for local testing)
- **Version Control**: Git

---

## 🛠️ **Installation Instructions**

To set up and run this project on your local machine, follow these steps:

### 1. **Clone the repository**
```bash
git clone https://github.com/softboyai/ecommerce-system.git
```

### 2. **Install XAMPP/WAMP**
Ensure that **XAMPP** or **WAMP** is installed to run PHP and MySQL locally.

### 3. **Set up the database**
- Open **phpMyAdmin** in your XAMPP/WAMP server.
- Create a database called `ecomm_db`.
- Import the provided `ecomm_db.sql` file located in the `db/` folder to set up the required tables.

### 4. **Configure the project**
- Edit the `config.php` file and set your database connection details:
  ```php
  $conn = new mysqli('localhost', 'root', '', 'ecomm_db');
  ```

### 5. **Start the server**
- Run **Apache** and **MySQL** from your XAMPP/WAMP control panel.
- Access the system in your browser at:
  ```
  http://localhost/ecommerce-system/
  ```

---

## 📦 **Usage**

### For Buyers:
- Browse available second-hand products.
- Search for specific products.
- Add products to your cart and proceed to checkout securely.
- Receive real-time notifications about your orders.

### For Admin (M/N Technology):
- Log in to manage products, inventory, and orders.
- Generate sales reports and track transactions.

---

## 📌 **Project Objectives**

1. Provide an easy-to-use platform for buyers.
2. Implement secure payment methods for safe transactions.
3. Ensure real-time notifications for better buyer engagement.

---

## 🚧 **Project Status**
- **Version 1.0** is currently available.
- Future updates will include advanced features such as personalized recommendations and enhanced buyer analytics.

---

## 🛡️ **Security Features**
- **Password hashing** for secure authentication.
- **Input validation** to prevent SQL injection attacks.
- **Secure payment processing** integrated with third-party gateways.

---

## 🤝 **Contributing**

Contributions are welcome! Here's how you can contribute:

1. Fork the repository.
2. Create a feature branch (`git checkout -b feature-branch`).
3. Commit your changes (`git commit -m 'Add new feature'`).
4. Push the branch (`git push origin feature-branch`).
5. Submit a Pull Request.

---

## 📄 **License**

This project is open-source and is licensed under the **MIT License**.

---

## 📝 **About**

Developed by **Kamanzi Jean Marie Vianney** for **M/N Technology at Makuza Peace Plaza**, as part of the Bachelor of Business Information Technology degree at **Mount Kenya University**. This project aims to provide a streamlined and buyer-focused ecommerce platform
